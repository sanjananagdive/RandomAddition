Font: https://fontesk.com/eazy-chat-font/


More Assets:
https://hcgamestudios.itch.io/

For any questions or suggestions, write to me at:
hcgamestudios@gmail.com